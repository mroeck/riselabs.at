---
title: "Carbon budgets for buildings: harmonizing temporal, spatial and sectoral dimensions"
kind: article
authors: "Habert G, Röck M, Steininger K, Lupíšek A, Birgisdottir H, Desing H, Chandrakumar C, Pittau F, Passer A, Rovers R, Slavkovic K, Hollberg A, Hoxha E, Jusselme T, Nault E, Allacker K, Lützkendorf T"
year: 2020
journal: "Buildings and Cities"
doi: "10.5334/bc.47"
people:
  - martin-roeck
# projects:                      # one or more, by filename
#   - project-filename
---

<!-- Optional: a paragraph about this publication shows on its page. -->
