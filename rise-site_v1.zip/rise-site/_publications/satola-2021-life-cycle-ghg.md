---
title: "Life cycle GHG emissions of residential buildings in humid subtropical and tropical climates: systematic review and analysis"
kind: article
authors: "Satola D, Röck M, Houlihan-Wiberg A, Gustavsen A"
year: 2021
journal: "Buildings"
doi: "10.3390/buildings11010006"
people:
  - martin-roeck
# projects:                      # one or more, by filename
#   - project-filename
---

<!-- Optional: a paragraph about this publication shows on its page. -->
