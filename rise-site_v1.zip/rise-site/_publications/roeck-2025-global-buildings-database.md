---
title: "A global buildings database: whole life cycle GHG emissions, energy performance, and material intensity"
kind: data
authors: "Röck M, Sørensen A, Balouktsi M, Ruschi Mendes Saade M, Rasmussen F, Alaux N, Hoxha E, Satola D, Truger B, Tozan B, Kuittinen M, Frischknecht R, Birgisdottir H, Habert G, Lützkendorf T, Allacker K, Passer A"
year: 2025
journal: "Zenodo"
doi: "10.5281/zenodo.8378938"
people:
  - martin-roeck
partners:
  - epfl
projects:
  - global-building-data-initiative
---

<!-- Optional: a paragraph about this publication shows on its page. -->
