---
title: "Environmental benchmarks for buildings: needs, challenges and solutions"
kind: article
authors: "Frischknecht R, Balouktsi M, Lützkendorf T, Aumann A, Birgisdottir H, Grosse Ruse E, Hollberg A, Kuittinen M, Lavagna M, Lupišek A, Passer A, Peuportier B, Ramseier L, Röck M, Trigaux D, Vancso D"
year: 2019
journal: "International Journal of Life Cycle Assessment"
doi: "10.1007/s11367-019-01690-y"
people:
  - martin-roeck
# projects:                      # one or more, by filename
#   - project-filename
---

<!-- Optional: a paragraph about this publication shows on its page. -->
