---
title: "LCA and BIM: visualization of environmental potentials in building construction at early design stages"
kind: article
authors: "Röck M, Hollberg A, Habert G, Passer A"
year: 2018
journal: "Building and Environment"
doi: "10.1016/j.buildenv.2018.05.006"
people:
  - martin-roeck
# projects:                      # one or more, by filename
#   - project-filename
---

<!-- Optional: a paragraph about this publication shows on its page. -->
